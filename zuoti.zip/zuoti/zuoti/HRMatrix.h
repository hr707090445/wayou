//
//  HRMatrix.h
//  zuoti
//
//  Created by HR on 2018/10/6.
//  Copyright © 2018年 HR. All rights reserved.
//

#ifndef HRMatrix_h
#define HRMatrix_h

#import "HRPoint.h"

struct HRMatrix {
   
    NSInteger column;
    NSInteger row;
    CGFloat matrix[4][4];
};

typedef struct HRMatrix HRMatrix;

static HRMatrix HRMatrixMake(NSInteger column, NSInteger row) {
    HRMatrix matrix;
    matrix.column = column;
    matrix.row = row;
    for (NSInteger i = 0; i < column; i++) {
        for (NSInteger j = 0; j < row; j++) {
            matrix.matrix[i][j] = 0;
        }
    }
    
    return matrix;
}


static HRMatrix HRMatrixMakeFromArray(NSInteger column, NSInteger row, CGFloat *data){
    
    HRMatrix matrix = HRMatrixMake(column, row);
    for (int i = 0; i < column; i++) {
        CGFloat *t = data + (i + row);
        for (int j = 0; j < row; j++) {
            matrix.matrix[i][j] = *(t + j);
        }
    }
    
    return matrix;
}


#endif /* HRMatrix_h */
