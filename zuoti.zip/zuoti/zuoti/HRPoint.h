//
//  HRPoint.h
//  zuoti
//
//  Created by HR on 2018/10/6.
//  Copyright © 2018年 HR. All rights reserved.
//

#ifndef HRPoint_h
#define HRPoint_h

struct HRPoint {
    CGFloat x;
    CGFloat y;
    CGFloat z;
};

typedef struct HRPoint HRPoint;

HRPoint HRPointMake(CGFloat x, CGFloat y, CGFloat z) {
    
    HRPoint point;
    point.x = x;
    point.y = y;
    point.z = z;
    
    return point;
}

#endif /* HRPoint_h */
