//
//  ViewController.m
//  zuoti
//
//  Created by HR on 2018/6/24.
//  Copyright © 2018年 HR. All rights reserved.
//

#import "ViewController.h"
#import "TableViewCell.h"
#import "HRMatrix.h"
#import "PersonTableViewController.h"


@interface ViewController ()<UITableViewDelegate,UITableViewDataSource>
@property (nonatomic, strong) UITableView *tableView;
@property (nonatomic, assign) NSIndexPath *lastIndex;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
//    self.view.backgroundColor = UIColor.whiteColor;
//    self.tableView = [[UITableView alloc]initWithFrame:CGRectMake(0, 120, self.view.frame.size.width, 200) style:UITableViewStylePlain];
//    self.tableView.delegate = self;
//    self.tableView.dataSource = self;
   // [self.view addSubview:self.tableView];
    
   // [self nsvalue];
    
    
    
    UIButton *button = [[UIButton alloc]init];
    button.frame = CGRectMake(20, 64, 100, 40);
    button.backgroundColor = UIColor.purpleColor;
    [button setTitle:@"跳转" forState:UIControlStateNormal];
    [button addTarget:self action:@selector(play) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:button];
    
}


- (void)play {
    
    [self.navigationController pushViewController:[[PersonTableViewController alloc]init] animated:YES];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 4;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    TableViewCell *cell  = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    if (!cell) {
        cell = [[[NSBundle mainBundle]loadNibNamed:@"TableViewCell" owner:nil options:nil] lastObject];
    }
    cell.title.text = [NSString stringWithFormat:@"%ld",(long)indexPath.row ];
    
    cell.buttonAction = ^(UIButton *sender) {
        UIButton *btn = sender;
        if (btn.tag == sender.tag) {
            btn.selected = YES;
        }else{
            btn.selected = NO;
        }
    };
    return cell;
}


- (void)nsvalue {
    HRPoint point;
    point.x = 20;
    point.y = 40;
    point.z = 60;
    
    
    NSValue *value = [NSValue valueWithBytes:&point objCType:@encode(HRPoint)];
    
    HRPoint point2;
    [value getValue:&point2];
    NSLog(@"%.f-----%.f------%.f",point2.x,point2.y,point2.z);
    

    
}

@end
