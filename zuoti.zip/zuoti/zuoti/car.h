//
//  car.h
//  zuoti
//
//  Created by HR on 2018/10/16.
//  Copyright © 2018年 HR. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface car : NSObject

/** 所有者 */
@property (nonatomic, strong) NSNumber *own_id;

/** 车的ID */
@property (nonatomic, strong) NSNumber *car_id;

@property (nonatomic, copy) NSString *brand;

@property (nonatomic, assign) NSInteger price;

@end
