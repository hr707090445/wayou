//
//  DataBase.m
//  zuoti
//
//  Created by HR on 2018/10/16.
//  Copyright © 2018年 HR. All rights reserved.
//

#import "DataBase.h"
#import "FMDB.h"
#import "person.h"
#import "car.h"
static DataBase *_DBCtl = nil;

@interface DataBase() <NSCopying,NSMutableCopying>
{
    FMDatabase *_db;
}

@end

@implementation DataBase


+(instancetype)sharedDataBase {
    if (_DBCtl == nil) {
        _DBCtl = [[DataBase alloc] init];
        
        [_DBCtl initDataBase];
    }
    return _DBCtl;
}

+ (instancetype)allocWithZone:(struct _NSZone *)zone {
    if (_DBCtl == nil) {
        _DBCtl = [super allocWithZone:zone];
    }
    return _DBCtl;
}

-(id)copy {
    return self;
}

-(id)mutableCopy {
    
    return self;
}

- (id)copyWithZone:(NSZone *)zone {
    
    return self;
}

- (id)mutableCopyWithZone:(NSZone *)zone {
    
    return self;
}

- (void)initDataBase {
    
    //document目录路径
    NSString *documentPath = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) lastObject];
    
    //文件路径
    NSString *filePath = [documentPath stringByAppendingPathComponent:@"test001.sqlite"];
    
    //实例化FMDB对象
    _db = [FMDatabase databaseWithPath:filePath];
    
    [_db open];
    
    //初始化数据表
    NSString *personSql = @"create table if not exists 'persons' ('id' integer primary key autoincrement not null,'person_id' text, 'person_name' text, 'person_age' text, 'person_number' text)";
    
    NSString *carSql = @"create table if not exists 'cars' ('id' integer primary key autoincrement not null, 'own_id' text, 'car_id' text, 'car_brand' text, 'car_price' text)";
    
    [_db executeUpdate:personSql];
    [_db executeUpdate:carSql];
    
    [_db close];
}


- (void)addPerson:(person *)person {
    [_db open];
    NSNumber *maxID = @(0);
    
    FMResultSet *res = [_db executeQuery:@"select * from persons"];
    
    //获取数据库中最大ID
    while ([res next]) {
        if ([maxID integerValue] < [[res stringForColumn:@"person_id"] integerValue]) {
            maxID = @([[res stringForColumn:@"person_id"] integerValue]);
        }
    }
    maxID = @([maxID integerValue] + 1);
    
    [_db executeUpdate:@"insert into persons(person_id,person_name,person_age,person_number) values(?,?,?,?)",maxID,person.name,@(person.age),@(person.number)];
    
    [_db close];
    
    
}

- (void)deletePerson:(person *)person {
    [_db open];
    
    [_db executeUpdate:@"delete from persons where person_id = ?",person.ID];
    
    [_db close];
}

- (void)updatePerson:(person *)person {
    [_db open];
    
    [_db executeUpdate:@"updata 'persons' sel person_name = ? where person_id = ?",person.name,person.ID];
    [_db executeUpdate:@"updata 'persons' sel person_age = ? where person_id",@(person.age),person.ID];
    [_db executeUpdate:@"updata 'persons' sel person_number = ? where person_id = ?",@(person.number),person.ID];
    [_db close];
}

- (NSMutableArray *)getAllPerson {
    [_db open];
    
    NSMutableArray *dataArray = [[NSMutableArray alloc] init];
    
    FMResultSet *res = [_db executeQuery:@"select *from persons"];
    
    while ([res next]) {
        person *persons = [[person alloc] init];
        persons.ID = @([[res stringForColumn:@"person_id"] integerValue]);
        persons.name = [res stringForColumn:@"person_name"];
        persons.age = [[res stringForColumn:@"person_age"] integerValue];
        persons.number = [[res stringForColumn:@"person_number"] integerValue];
        
        [dataArray addObject:persons];
    }
    
    [_db close];
    
    return dataArray;
}

- (void)addCar:(car *)car toPerson:(person *)person {
    [_db open];
    
    //根据person 是否拥有car来添加car_id
    NSNumber *maxID = @(0);
    
    FMResultSet *res = [_db executeQuery:[NSString stringWithFormat:@"select * from cars where own_id = %@",person.ID]];
    
    while ([res next]) {
        if ([maxID integerValue] < [[res stringForColumn:@"car_id"] integerValue]) {
            maxID = @([[res stringForColumn:@"car_id"] integerValue]);
        }
        
    }
     maxID = @([maxID integerValue] + 1);
    [_db executeUpdate:@"insert into cars(own_id,car_id,car_brand,car_price) value (?,?,?,?)",person.ID,maxID,car.brand,@(car.price)];
    [_db close];
}

- (void)deleteCar:(car *)car fromPerson:(person *)person {
    [_db open];
    
    [_db executeUpdate:@"delete from cars where own_id = ? and car_id = ?",person.ID,car.car_id];
    
    [_db close];
}

- (NSMutableArray *)getAllCarsFromPerson:(person *)person {
    
    [_db open];
    
    NSMutableArray *carArray = [[NSMutableArray alloc] init];
    
    FMResultSet *res = [_db executeQuery:[NSString stringWithFormat:@"select * from cars where own_id = %@",person.ID]];
    
    while ([res next]) {
        car *cars = [[car alloc] init];
        cars.own_id = person.ID;
        cars.car_id = @([[res stringForColumn:@"car_id"] integerValue]);
        cars.brand = [res stringForColumn:@"car_brand"];
        cars.price = [[res stringForColumn:@"car_price"] integerValue];
        
        [carArray addObject:cars];
    }
    
    [_db close];
    
    return carArray;
}

- (void)deleteAllCarsFromPerson:(person *)person {
    
    [_db open];
    
    [_db executeUpdate:@"delete from cars where own_id = ?",person.ID];
    
    [_db close];
}
@end
