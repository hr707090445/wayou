//
//  TableViewCell.m
//  zuoti
//
//  Created by HR on 2018/6/24.
//  Copyright © 2018年 HR. All rights reserved.
//

#import "TableViewCell.h"

@implementation TableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    [self.btn setImage:[UIImage imageNamed:@"选中_n"] forState:UIControlStateNormal];
    [self.btn setImage:[UIImage imageNamed:@"选中_s"] forState:UIControlStateSelected];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
- (IBAction)button:(id)sender {
    if (self.buttonAction) {
        self.buttonAction(sender);
    }
}

@end
