//
//  PersonTableViewController.m
//  zuoti
//
//  Created by HR on 2018/10/16.
//  Copyright © 2018年 HR. All rights reserved.
//

#import "PersonTableViewController.h"
#import "DataBase.h"
#import "person.h"
#import "car.h"



@interface PersonTableViewController ()

@property(nonatomic, strong) NSMutableArray *dataArray;

@end

@implementation PersonTableViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc]initWithBarButtonSystemItem:UIBarButtonSystemItemAdd target:self action:@selector(addData)];
    
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"查看车辆" style:UIBarButtonItemStylePlain target:self action:@selector(watchCars)];
    
    [self.tableView registerClass:[UITableViewCell class] forCellReuseIdentifier:@"cell"];
}



- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    self.dataArray = [[DataBase sharedDataBase]getAllPerson];
    
}
- (void)addData {
    
    int nameRandom = arc4random_uniform(1000);
    NSInteger ageRandom = arc4random_uniform(100) + 1;
    
    NSString *name = [NSString stringWithFormat:@"person_%d号",nameRandom];
    NSInteger age = ageRandom;
    
    person *persons = [[person alloc] init];
    persons.name = name;
    persons.age = age;
    
    [[DataBase sharedDataBase] addPerson:persons];
    
    self.dataArray = [[DataBase sharedDataBase]getAllPerson];
    
    
    
    [self.tableView reloadData];
}


- (void)watchCars {
    
    NSLog(@"查看车辆");
}
#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
#warning Incomplete implementation, return the number of sections
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
#warning Incomplete implementation, return the number of rows
    return self.dataArray.count;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell" forIndexPath:indexPath];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:@"cell"];
    }
    
    person *persons = self.dataArray[indexPath.row];
    cell.textLabel.text = persons.name;
    
    cell.detailTextLabel.text = [NSString stringWithFormat:@"%ld岁",(long)persons.age];
    
    return cell;
}


- (NSMutableArray *)dataArray {
    if (!_dataArray) {
        _dataArray = [NSMutableArray array];
    }
    
    return _dataArray;
}
@end
