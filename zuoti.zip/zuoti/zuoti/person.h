//
//  person.h
//  zuoti
//
//  Created by HR on 2018/10/16.
//  Copyright © 2018年 HR. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface person : NSObject

@property (nonatomic, strong) NSNumber *ID;

@property (nonatomic, copy) NSString *name;

@property (nonatomic, assign) NSInteger age;

@property (nonatomic, assign) NSInteger number;

/**
 一个人可以拥有多辆车
 */
@property (nonatomic, strong) NSMutableArray *carArray;

@end
