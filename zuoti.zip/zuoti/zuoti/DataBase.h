//
//  DataBase.h
//  zuoti
//
//  Created by HR on 2018/10/16.
//  Copyright © 2018年 HR. All rights reserved.
//

#import <Foundation/Foundation.h>
@class person,car;
@interface DataBase : NSObject

@property (nonatomic, strong) person *persons;

+(instancetype)sharedDataBase;

#pragma mark - person


/**
 添加person
 */
- (void)addPerson:(person *)person;

- (void)deletePerson:(person *)person;

- (void)updatePerson:(person *)person;

- (NSMutableArray *)getAllPerson;



#pragma mark - Car
- (void)addCar:(car *)car toPerson:(person *)person;

- (void)deleteCar:(car *)car fromPerson:(person *)person;

- (NSMutableArray *)getAllCarsFromPerson:(person *)person;

- (void)deleteAllCarsFromPerson:(person *)person;

@end
