//
//  DataBaseSql.m
//  zuoti
//
//  Created by HR on 2018/10/17.
//  Copyright © 2018年 HR. All rights reserved.
//

#import "DataBaseSql.h"
#import "FMDB.h"

@interface DataBaseSql ()

@property (nonatomic, strong)FMDatabase *db;

@end

@implementation DataBaseSql


- (void)createDataBase {
    // 创建数据库
    //1.获取数据库文件路径
    NSString *documentPath = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) lastObject];
    NSString *filePath = [documentPath stringByAppendingPathComponent:@"student.sqlite"];
    
    //2.初始化数据库
    self.db = [[FMDatabase alloc] initWithPath:filePath];
    
    //创建数据库中的表
    if (self.db) {
        if ([self.db open]) {
            BOOL stuSql = [self.db executeUpdate:@"create table if not exists 'student' ('id' integer primary key autoincrement not null, 'stu_id' text, 'stu_name' text, 'str_pic' text)"];
            
            if (stuSql) {
                NSLog(@"数据库创建表成功");
            } else {
                
                NSLog(@"创建表失败");
            }
        } else{
            NSLog(@"数据库没有打开");
        }
        
    } else {
        NSLog(@"创建数据库失败");
    }
    
    [self.db close];
    
    
}
@end
