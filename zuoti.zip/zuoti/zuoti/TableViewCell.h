//
//  TableViewCell.h
//  zuoti
//
//  Created by HR on 2018/6/24.
//  Copyright © 2018年 HR. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef void(^ButtonAction)(UIButton *sender);

@interface TableViewCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UIButton *btn;
@property (weak, nonatomic) IBOutlet UILabel *title;
@property (nonatomic, copy) ButtonAction buttonAction;
@end
